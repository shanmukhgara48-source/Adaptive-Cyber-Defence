"""
training/train_dqn.py

Trains the DQN agent against the Adaptive Cyber Defense Simulator.

Usage:
    python training/train_dqn.py \
        --episodes 200 \
        --seed 42 \
        --save-path models/dqn_cyber.pt \
        --env-url http://localhost:8000   # optional: override base URL

Design decisions:
- The environment is accessed via its existing step()/reset()/state() API.
  Nothing in the existing codebase is modified.
- State is flattened to a fixed-length float vector (see flatten_state()).
- Actions are mapped to the environment's action strings via ACTION_MAP.
- Rewards come directly from the environment step response (no re-shaping
  that could leak threat_type; we use only the score delta as reward).
- Training metrics are logged to training/logs/dqn_training.jsonl for
  post-mortem analysis without touching replay.py or grader.py.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

# Make sure project root is importable
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from agents.dqn_agent import DQNAgent


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

# Map integer action indices -> environment action strings.
# Extend this to match your environment's full action space.
ACTION_MAP: Dict[int, Dict[str, Any]] = {
    0: {"action": "block_ip",          "params": {}},
    1: {"action": "isolate_machine",   "params": {}},
    2: {"action": "patch",             "params": {}},
    3: {"action": "scan",              "params": {}},
    4: {"action": "restore",           "params": {}},
    5: {"action": "monitor",           "params": {}},
}

N_ACTIONS = len(ACTION_MAP)

# IOC keys used to build the state vector (order must stay fixed).
# All values are normalised to [0, 1] before feeding to the network.
IOC_KEYS: List[str] = [
    "packets_per_second",
    "failed_auth_attempts",
    "lateral_connection_count",
    "data_exfil_mb",
    "cpu_usage",
    "memory_usage",
    "open_ports",
    "privilege_escalation_attempts",
]

# Extra scalar state features appended after IOC values.
SCALAR_KEYS: List[str] = [
    "system_health",
    "resources_remaining",
    "step_count",
    "threat_count",
]

STATE_DIM = len(IOC_KEYS) + len(SCALAR_KEYS)

# Normalisation ceilings for each IOC/scalar (rough domain estimates).
NORM_CEIL: Dict[str, float] = {
    "packets_per_second":             100_000.0,
    "failed_auth_attempts":           500.0,
    "lateral_connection_count":       200.0,
    "data_exfil_mb":                  1_000.0,
    "cpu_usage":                      100.0,
    "memory_usage":                   100.0,
    "open_ports":                     65_535.0,
    "privilege_escalation_attempts":  50.0,
    "system_health":                  100.0,
    "resources_remaining":            100.0,
    "step_count":                     200.0,
    "threat_count":                   50.0,
}


# ---------------------------------------------------------------------------
# Environment adapter helpers
# ---------------------------------------------------------------------------

def _safe_get(d: dict, key: str, default: float = 0.0) -> float:
    """Safely extract a numeric value from a nested dict/object."""
    val = d
    for part in key.split("."):
        if isinstance(val, dict):
            val = val.get(part, default)
        else:
            val = getattr(val, part, default)
    try:
        return float(val)
    except (TypeError, ValueError):
        return default


def flatten_state(state: dict) -> np.ndarray:
    """
    Convert the environment state dict into a fixed-length float32 vector.

    Falls back to 0.0 for any key not present in the state, so this function
    remains safe even if the environment adds/removes keys between versions.
    """
    all_keys = IOC_KEYS + SCALAR_KEYS
    vec = np.zeros(len(all_keys), dtype=np.float32)

    # Merge top-level and nested ioc/metrics sub-dicts for convenience
    flat: dict = {}
    flat.update(state)
    for sub in ("ioc", "metrics", "node", "nodes"):
        if isinstance(state.get(sub), dict):
            flat.update(state[sub])

    for i, key in enumerate(all_keys):
        raw = _safe_get(flat, key, 0.0)
        ceil = NORM_CEIL.get(key, 1.0)
        vec[i] = np.clip(raw / ceil, 0.0, 1.0)

    return vec


# ---------------------------------------------------------------------------
# Thin environment wrapper
# ---------------------------------------------------------------------------

class CyberEnvAdapter:
    """
    Wraps the existing environment API for RL interaction.

    This adapter calls the environment's own step()/reset()/state() methods
    without modifying any of the original files.
    """

    def __init__(self, env_module_path: str = "environment", seed: Optional[int] = None):
        """
        Args:
            env_module_path: Python import path for the environment module.
                             Defaults to 'environment' (project root).
            seed:            Optional seed forwarded to env.reset().
        """
        self.seed = seed
        self._env = self._import_env(env_module_path)
        self._prev_score: float = 0.0
        self._step_num: int = 0

    @staticmethod
    def _import_env(module_path: str):
        """Dynamically import the environment to avoid coupling."""
        import importlib
        mod = importlib.import_module(module_path)
        # Try common attribute names
        for name in ("env", "environment", "CyberDefenseEnv", "Env"):
            if hasattr(mod, name):
                candidate = getattr(mod, name)
                if callable(candidate):
                    return candidate()
                return candidate
        # Last resort: the module itself exposes step/reset/state at module level
        return mod

    def reset(self) -> np.ndarray:
        kwargs = {"seed": self.seed} if self.seed is not None else {}
        state = self._env.reset(**kwargs)
        self._prev_score = 0.0
        self._step_num = 0
        return flatten_state(state if isinstance(state, dict) else state.__dict__)

    def step(self, action_idx: int) -> Tuple[np.ndarray, float, bool, dict]:
        action_payload = ACTION_MAP[action_idx]
        result = self._env.step(**action_payload)

        # result is expected to be a dict or object with fields:
        #   state, score (or reward), done, info
        if isinstance(result, tuple):
            state_raw, reward, done, info = result
        else:
            state_raw = getattr(result, "state", result)
            reward = float(getattr(result, "reward", getattr(result, "score", 0.0)))
            done = bool(getattr(result, "done", False))
            info = getattr(result, "info", {})

        # Use score delta as reward signal to avoid reward hacking
        score = float(reward)
        reward_delta = score - self._prev_score
        self._prev_score = score
        self._step_num += 1

        next_state = flatten_state(
            state_raw if isinstance(state_raw, dict) else state_raw.__dict__
        )
        return next_state, reward_delta, done, info

    def state(self) -> np.ndarray:
        raw = self._env.state()
        return flatten_state(raw if isinstance(raw, dict) else raw.__dict__)


# ---------------------------------------------------------------------------
# Training loop
# ---------------------------------------------------------------------------

def train(
    env_module: str = "environment",
    n_episodes: int = 200,
    max_steps_per_episode: int = 50,
    seed: int = 42,
    save_path: str = "models/dqn_cyber.pt",
    log_dir: str = "training/logs",
    eval_every: int = 20,
    warmup_episodes: int = 10,
    verbose: bool = True,
) -> None:
    """
    Main training loop.

    Args:
        env_module:             Import path of the environment.
        n_episodes:             Total training episodes.
        max_steps_per_episode: Truncation limit per episode.
        seed:                  RNG seed (forwarded to env and torch).
        save_path:             Where to save the final model weights.
        log_dir:               Directory for JSONL training logs.
        eval_every:            Log a progress summary every N episodes.
        warmup_episodes:       Fill replay buffer for N episodes before training.
        verbose:               Print progress.
    """
    import random as stdlib_random
    stdlib_random.seed(seed)
    np.random.seed(seed)
    if "torch" in sys.modules:
        import torch
        torch.manual_seed(seed)

    os.makedirs(log_dir, exist_ok=True)
    os.makedirs(os.path.dirname(save_path) if os.path.dirname(save_path) else ".", exist_ok=True)
    log_path = os.path.join(log_dir, "dqn_training.jsonl")

    env = CyberEnvAdapter(env_module_path=env_module, seed=seed)

    agent = DQNAgent(
        state_dim=STATE_DIM,
        n_actions=N_ACTIONS,
        lr=1e-3,
        gamma=0.99,
        epsilon_start=1.0,
        epsilon_min=0.05,
        epsilon_decay=0.995,
        buffer_size=10_000,
        batch_size=64,
        target_update=50,
        device="cpu",          # resource-safe default
    )

    best_score = -float("inf")
    episode_rewards: List[float] = []

    for ep in range(1, n_episodes + 1):
        state = env.reset()
        ep_reward = 0.0
        ep_loss_sum = 0.0
        ep_updates = 0

        for step in range(max_steps_per_episode):
            training_mode = ep > warmup_episodes
            action = agent.select_action(state, training=training_mode)
            next_state, reward, done, _ = env.step(action)

            agent.store(state, action, reward, next_state, done)

            if training_mode:
                loss = agent.update()
                if loss is not None:
                    ep_loss_sum += loss
                    ep_updates += 1

            state = next_state
            ep_reward += reward

            if done:
                break

        episode_rewards.append(ep_reward)
        avg_loss = ep_loss_sum / max(ep_updates, 1)
        recent_avg = float(np.mean(episode_rewards[-20:]))

        log_entry = {
            "episode": ep,
            "reward": round(ep_reward, 4),
            "recent_avg_reward": round(recent_avg, 4),
            "epsilon": round(agent.epsilon, 4),
            "avg_loss": round(avg_loss, 6),
            "buffer_size": len(agent.buffer),
            "timestamp": time.time(),
        }

        with open(log_path, "a") as f:
            f.write(json.dumps(log_entry) + "\n")

        if ep_reward > best_score:
            best_score = ep_reward
            agent.save(save_path.replace(".pt", "_best.pt"))

        if verbose and (ep % eval_every == 0 or ep == 1):
            print(
                f"[Ep {ep:>4}/{n_episodes}] "
                f"reward={ep_reward:+.3f}  "
                f"avg20={recent_avg:+.3f}  "
                f"ε={agent.epsilon:.3f}  "
                f"loss={avg_loss:.5f}  "
                f"buf={len(agent.buffer)}"
            )

    agent.save(save_path)
    print(f"\nTraining complete. Best episode reward: {best_score:.4f}")
    print(f"Model saved to: {save_path}")
    print(f"Training log:   {log_path}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Train DQN agent on Cyber Defense Sim")
    p.add_argument("--env-module",   default="environment",       help="Import path for env module")
    p.add_argument("--episodes",     type=int,   default=200,     help="Training episodes")
    p.add_argument("--max-steps",    type=int,   default=50,      help="Max steps per episode")
    p.add_argument("--seed",         type=int,   default=42,      help="RNG seed")
    p.add_argument("--save-path",    default="models/dqn_cyber.pt")
    p.add_argument("--log-dir",      default="training/logs")
    p.add_argument("--eval-every",   type=int,   default=20,      help="Log frequency (episodes)")
    p.add_argument("--warmup",       type=int,   default=10,      help="Warmup episodes")
    p.add_argument("--quiet",        action="store_true")
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    train(
        env_module=args.env_module,
        n_episodes=args.episodes,
        max_steps_per_episode=args.max_steps,
        seed=args.seed,
        save_path=args.save_path,
        log_dir=args.log_dir,
        eval_every=args.eval_every,
        warmup_episodes=args.warmup,
        verbose=not args.quiet,
    )
