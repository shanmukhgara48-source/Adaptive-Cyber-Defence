"""
agents/dqn_agent.py

Lightweight DQN agent for the Adaptive Cyber Defense Simulator.
Uses a simple MLP Q-network with epsilon-greedy exploration.

Design decisions:
- Pure numpy/stdlib for the replay buffer (no torch dependency for the buffer)
- PyTorch only for the neural net (small MLP, CPU-friendly)
- Epsilon decay is multiplicative for stability
- Target network updated every `target_update` steps (hard copy)
"""

from __future__ import annotations

import random
import os
from collections import deque
from typing import List, Tuple, Optional
import numpy as np

try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    import torch.nn.functional as F
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False


# ---------------------------------------------------------------------------
# Replay buffer
# ---------------------------------------------------------------------------

class ReplayBuffer:
    """Fixed-size circular buffer storing (s, a, r, s', done) tuples."""

    def __init__(self, capacity: int = 10_000):
        self.buffer: deque = deque(maxlen=capacity)

    def push(
        self,
        state: np.ndarray,
        action: int,
        reward: float,
        next_state: np.ndarray,
        done: bool,
    ) -> None:
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size: int) -> Tuple:
        batch = random.sample(self.buffer, batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)
        return (
            np.array(states, dtype=np.float32),
            np.array(actions, dtype=np.int64),
            np.array(rewards, dtype=np.float32),
            np.array(next_states, dtype=np.float32),
            np.array(dones, dtype=np.float32),
        )

    def __len__(self) -> int:
        return len(self.buffer)


# ---------------------------------------------------------------------------
# Q-Network (MLP)
# ---------------------------------------------------------------------------

class QNetwork(nn.Module):
    """
    Two-hidden-layer MLP.

    Architecture kept minimal for CPU inference:
      input_dim -> 128 -> 64 -> n_actions
    """

    def __init__(self, input_dim: int, n_actions: int, hidden_sizes: Tuple[int, int] = (128, 64)):
        super().__init__()
        h1, h2 = hidden_sizes
        self.net = nn.Sequential(
            nn.Linear(input_dim, h1),
            nn.ReLU(),
            nn.Linear(h1, h2),
            nn.ReLU(),
            nn.Linear(h2, n_actions),
        )

    def forward(self, x: "torch.Tensor") -> "torch.Tensor":
        return self.net(x)


# ---------------------------------------------------------------------------
# DQN Agent
# ---------------------------------------------------------------------------

class DQNAgent:
    """
    Standard DQN agent with:
    - Epsilon-greedy exploration (multiplicative decay)
    - Experience replay
    - Target network (hard update every `target_update` steps)

    Args:
        state_dim:      Dimensionality of the flat state vector.
        n_actions:      Number of discrete actions.
        lr:             Adam learning rate.
        gamma:          Discount factor.
        epsilon_start:  Initial exploration rate.
        epsilon_min:    Floor on exploration.
        epsilon_decay:  Multiplicative decay applied after each step.
        buffer_size:    Replay buffer capacity.
        batch_size:     Minibatch size for gradient updates.
        target_update:  How many steps between target network syncs.
        device:         "cpu" or "cuda". Defaults to CPU (resource-safe).
    """

    def __init__(
        self,
        state_dim: int,
        n_actions: int,
        lr: float = 1e-3,
        gamma: float = 0.99,
        epsilon_start: float = 1.0,
        epsilon_min: float = 0.05,
        epsilon_decay: float = 0.995,
        buffer_size: int = 10_000,
        batch_size: int = 64,
        target_update: int = 50,
        device: str = "cpu",
    ):
        if not TORCH_AVAILABLE:
            raise ImportError(
                "PyTorch is required for DQNAgent. "
                "Install it with: pip install torch --index-url https://download.pytorch.org/whl/cpu"
            )

        self.state_dim = state_dim
        self.n_actions = n_actions
        self.gamma = gamma
        self.epsilon = epsilon_start
        self.epsilon_min = epsilon_min
        self.epsilon_decay = epsilon_decay
        self.batch_size = batch_size
        self.target_update = target_update
        self.device = torch.device(device)

        # Networks
        self.policy_net = QNetwork(state_dim, n_actions).to(self.device)
        self.target_net = QNetwork(state_dim, n_actions).to(self.device)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.target_net.eval()

        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=lr)
        self.buffer = ReplayBuffer(buffer_size)

        self._step_count: int = 0
        self.losses: List[float] = []

    # ------------------------------------------------------------------
    # Action selection
    # ------------------------------------------------------------------

    def select_action(self, state: np.ndarray, training: bool = True) -> int:
        """Epsilon-greedy action selection."""
        if training and random.random() < self.epsilon:
            return random.randint(0, self.n_actions - 1)

        state_t = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        with torch.no_grad():
            q_values = self.policy_net(state_t)
        return int(q_values.argmax(dim=1).item())

    # ------------------------------------------------------------------
    # Learning
    # ------------------------------------------------------------------

    def store(
        self,
        state: np.ndarray,
        action: int,
        reward: float,
        next_state: np.ndarray,
        done: bool,
    ) -> None:
        self.buffer.push(state, action, reward, next_state, done)

    def update(self) -> Optional[float]:
        """
        Sample a minibatch and perform one gradient step.
        Returns the loss value, or None if the buffer is too small.
        """
        if len(self.buffer) < self.batch_size:
            return None

        states, actions, rewards, next_states, dones = self.buffer.sample(self.batch_size)

        states_t      = torch.FloatTensor(states).to(self.device)
        actions_t     = torch.LongTensor(actions).to(self.device)
        rewards_t     = torch.FloatTensor(rewards).to(self.device)
        next_states_t = torch.FloatTensor(next_states).to(self.device)
        dones_t       = torch.FloatTensor(dones).to(self.device)

        # Current Q(s, a)
        q_vals = self.policy_net(states_t).gather(1, actions_t.unsqueeze(1)).squeeze(1)

        # Target: r + gamma * max_a' Q_target(s', a')
        with torch.no_grad():
            next_q = self.target_net(next_states_t).max(1)[0]
            target_q = rewards_t + self.gamma * next_q * (1.0 - dones_t)

        loss = F.smooth_l1_loss(q_vals, target_q)

        self.optimizer.zero_grad()
        loss.backward()
        # Gradient clipping keeps training stable on a noisy reward signal
        nn.utils.clip_grad_norm_(self.policy_net.parameters(), max_norm=10.0)
        self.optimizer.step()

        self._step_count += 1
        loss_val = loss.item()
        self.losses.append(loss_val)

        # Decay epsilon
        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)

        # Sync target network
        if self._step_count % self.target_update == 0:
            self.target_net.load_state_dict(self.policy_net.state_dict())

        return loss_val

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(path) if os.path.dirname(path) else ".", exist_ok=True)
        torch.save(
            {
                "policy_state_dict": self.policy_net.state_dict(),
                "target_state_dict": self.target_net.state_dict(),
                "optimizer_state_dict": self.optimizer.state_dict(),
                "epsilon": self.epsilon,
                "step_count": self._step_count,
                "config": {
                    "state_dim": self.state_dim,
                    "n_actions": self.n_actions,
                    "gamma": self.gamma,
                },
            },
            path,
        )
        print(f"[DQNAgent] Saved to {path}")

    @classmethod
    def load(cls, path: str, device: str = "cpu") -> "DQNAgent":
        checkpoint = torch.load(path, map_location=device)
        cfg = checkpoint["config"]
        agent = cls(
            state_dim=cfg["state_dim"],
            n_actions=cfg["n_actions"],
            gamma=cfg["gamma"],
            device=device,
        )
        agent.policy_net.load_state_dict(checkpoint["policy_state_dict"])
        agent.target_net.load_state_dict(checkpoint["target_state_dict"])
        agent.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        agent.epsilon = checkpoint["epsilon"]
        agent._step_count = checkpoint["step_count"]
        print(f"[DQNAgent] Loaded from {path} (ε={agent.epsilon:.3f}, steps={agent._step_count})")
        return agent
