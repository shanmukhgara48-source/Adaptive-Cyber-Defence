"""
benchmark/compare_agents.py

Multi-agent benchmark platform for the Adaptive Cyber Defense Simulator.

Runs three agents on the same seed(s) and outputs a comparison table:
  1. LLM agent   — the existing inference.py agent (subprocess call)
  2. Heuristic   — rule-based baseline (no ML, no LLM)
  3. DQN agent   — trained RL agent loaded from weights file

Usage:
    python benchmark/compare_agents.py \
        --seeds 42 43 44 \
        --dqn-model models/dqn_cyber.pt \
        --episodes 5 \
        --max-steps 50

Design decisions:
- The LLM agent is invoked via subprocess (inference.py) to avoid any
  coupling with its internals and to match the real judging setup.
- The heuristic agent encodes simple priority rules (highest threat score
  first) and serves as a sanity-check lower bound.
- All agents are evaluated on the SAME seeds for fair comparison.
- Output is a clean table printed to stdout + saved as benchmark/results.json.
- No existing files are modified.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from training.train_dqn import (
    CyberEnvAdapter,
    ACTION_MAP,
    N_ACTIONS,
    STATE_DIM,
    flatten_state,
)
from agents.dqn_agent import DQNAgent


# ---------------------------------------------------------------------------
# Heuristic agent
# ---------------------------------------------------------------------------

class HeuristicAgent:
    """
    Rule-based baseline agent.

    Priority logic (no learning, no LLM):
      1. If failed_auth_attempts is high -> block_ip  (idx 0)
      2. If lateral_connection_count is high -> isolate_machine  (idx 1)
      3. If data_exfil_mb is high -> patch  (idx 2)
      4. Default -> scan  (idx 3)

    Thresholds are normalised [0, 1] consistent with flatten_state().
    """

    # Indices into the flat state vector (must match IOC_KEYS in train_dqn.py)
    _IDX = {
        "packets_per_second":            0,
        "failed_auth_attempts":          1,
        "lateral_connection_count":      2,
        "data_exfil_mb":                 3,
        "cpu_usage":                     4,
        "memory_usage":                  5,
        "open_ports":                    6,
        "privilege_escalation_attempts": 7,
        "system_health":                 8,
        "resources_remaining":           9,
    }

    HIGH = 0.4   # normalised threshold to trigger a response
    MED  = 0.2

    def select_action(self, state: np.ndarray) -> int:
        failed_auth   = state[self._IDX["failed_auth_attempts"]]
        lateral       = state[self._IDX["lateral_connection_count"]]
        exfil         = state[self._IDX["data_exfil_mb"]]
        privesc       = state[self._IDX["privilege_escalation_attempts"]]
        health        = state[self._IDX["system_health"]]
        resources     = state[self._IDX["resources_remaining"]]

        if failed_auth > self.HIGH:
            return 0   # block_ip
        if lateral > self.HIGH:
            return 1   # isolate_machine
        if exfil > self.MED or privesc > self.MED:
            return 2   # patch
        if health < 0.5 and resources > 0.3:
            return 4   # restore
        if resources < 0.2:
            return 5   # monitor (cheapest action)
        return 3       # scan (gather info)


# ---------------------------------------------------------------------------
# LLM agent runner (subprocess)
# ---------------------------------------------------------------------------

class LLMAgentRunner:
    """
    Wraps inference.py as a black-box subprocess.

    The LLM agent is invoked once per episode via:
        python inference.py --seed <seed> --max-steps <max_steps>

    Expected stdout: a JSON line with at minimum {"score": float}.
    Adjust `_parse_result` if your inference.py emits a different format.
    """

    def __init__(
        self,
        inference_script: str = "inference.py",
        timeout: int = 120,
    ):
        self.inference_script = inference_script
        self.timeout = timeout

    def run_episode(self, seed: int, max_steps: int = 50) -> Dict[str, Any]:
        cmd = [
            sys.executable,
            self.inference_script,
            "--seed", str(seed),
            "--max-steps", str(max_steps),
        ]
        try:
            t0 = time.time()
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.timeout,
            )
            elapsed = time.time() - t0

            if result.returncode != 0:
                return {"score": 0.0, "error": result.stderr[:500], "elapsed": elapsed}

            return self._parse_result(result.stdout, elapsed)

        except subprocess.TimeoutExpired:
            return {"score": 0.0, "error": "timeout", "elapsed": self.timeout}
        except Exception as e:
            return {"score": 0.0, "error": str(e), "elapsed": 0.0}

    @staticmethod
    def _parse_result(stdout: str, elapsed: float) -> Dict[str, Any]:
        """
        Parse inference.py output.

        Tries to find a JSON line containing 'score'. Falls back to 0.0.
        Adjust this parser to match your inference.py output format.
        """
        for line in reversed(stdout.strip().splitlines()):
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
                if "score" in data:
                    data["elapsed"] = elapsed
                    return data
            except json.JSONDecodeError:
                # Try to extract a float if the script just prints the score
                try:
                    score = float(line.split()[-1])
                    return {"score": score, "elapsed": elapsed}
                except (ValueError, IndexError):
                    continue
        return {"score": 0.0, "elapsed": elapsed, "error": "unparseable output"}


# ---------------------------------------------------------------------------
# Episode runner for in-process agents (heuristic + DQN)
# ---------------------------------------------------------------------------

def run_episode_in_process(
    agent,
    env_module: str,
    seed: int,
    max_steps: int,
) -> Dict[str, Any]:
    """Run one episode for any agent that exposes select_action(state) -> int."""
    env = CyberEnvAdapter(env_module_path=env_module, seed=seed)
    state = env.reset()

    total_reward = 0.0
    actions_taken = []
    t0 = time.time()

    for step in range(max_steps):
        action_idx = agent.select_action(state)
        actions_taken.append(ACTION_MAP[action_idx]["action"])
        next_state, reward, done, info = env.step(action_idx)
        total_reward += reward
        state = next_state
        if done:
            break

    elapsed = time.time() - t0
    score = float(np.clip(total_reward, 0.0, 1.0))

    return {
        "score": score,
        "raw_reward": total_reward,
        "steps": step + 1,
        "elapsed": elapsed,
        "actions": actions_taken,
    }


# ---------------------------------------------------------------------------
# Benchmark runner
# ---------------------------------------------------------------------------

def benchmark(
    seeds: List[int],
    dqn_model_path: Optional[str],
    env_module: str,
    n_episodes_per_seed: int,
    max_steps: int,
    inference_script: str,
    run_llm: bool,
    output_path: str,
) -> None:

    agents_to_run = []

    # --- Heuristic ---
    agents_to_run.append(("Heuristic", "in_process", HeuristicAgent()))

    # --- DQN ---
    if dqn_model_path and os.path.exists(dqn_model_path):
        dqn = DQNAgent.load(dqn_model_path, device="cpu")
        dqn.epsilon = 0.0    # pure greedy at eval time
        agents_to_run.append(("DQN", "in_process", dqn))
    else:
        if dqn_model_path:
            print(f"[warn] DQN model not found at {dqn_model_path} — skipping DQN agent.")

    # --- LLM (subprocess) ---
    llm_runner = None
    if run_llm and os.path.exists(inference_script):
        llm_runner = LLMAgentRunner(inference_script=inference_script)
        agents_to_run.append(("LLM", "subprocess", llm_runner))
    elif run_llm:
        print(f"[warn] {inference_script} not found — skipping LLM agent.")

    print("\n" + "=" * 70)
    print("  ADAPTIVE CYBER DEFENSE — MULTI-AGENT BENCHMARK")
    print("=" * 70)
    print(f"  Seeds:            {seeds}")
    print(f"  Episodes/seed:    {n_episodes_per_seed}")
    print(f"  Max steps/ep:     {max_steps}")
    print(f"  Agents:           {[name for name, _, _ in agents_to_run]}")
    print("=" * 70 + "\n")

    all_results: Dict[str, List[Dict]] = {name: [] for name, _, _ in agents_to_run}

    for seed in seeds:
        print(f"--- Seed {seed} ---")
        for _ in range(n_episodes_per_seed):
            for name, mode, agent_obj in agents_to_run:
                if mode == "in_process":
                    res = run_episode_in_process(agent_obj, env_module, seed, max_steps)
                else:
                    # LLM subprocess — seed-based, not repeated within seed
                    res = agent_obj.run_episode(seed=seed, max_steps=max_steps)

                res["seed"] = seed
                all_results[name].append(res)
                print(f"  [{name:10s}] score={res['score']:.4f}  elapsed={res['elapsed']:.1f}s")

    print()

    # ------------------------------------------------------------------
    # Summary table
    # ------------------------------------------------------------------
    col_w = 14
    header = (
        f"{'Agent':<12} "
        f"{'Mean Score':>{col_w}} "
        f"{'Std Dev':>{col_w}} "
        f"{'Min Score':>{col_w}} "
        f"{'Max Score':>{col_w}} "
        f"{'Avg Time(s)':>{col_w}}"
    )
    sep = "-" * len(header)

    print("=" * len(header))
    print("  RESULTS SUMMARY")
    print("=" * len(header))
    print(header)
    print(sep)

    summary: Dict[str, Dict] = {}
    for name, _, _ in agents_to_run:
        results = all_results[name]
        scores = [r["score"] for r in results]
        times  = [r["elapsed"] for r in results]
        s = {
            "mean":  float(np.mean(scores)),
            "std":   float(np.std(scores)),
            "min":   float(np.min(scores)),
            "max":   float(np.max(scores)),
            "avg_elapsed": float(np.mean(times)),
            "n_episodes": len(results),
        }
        summary[name] = s
        print(
            f"{name:<12} "
            f"{s['mean']:>{col_w}.4f} "
            f"{s['std']:>{col_w}.4f} "
            f"{s['min']:>{col_w}.4f} "
            f"{s['max']:>{col_w}.4f} "
            f"{s['avg_elapsed']:>{col_w}.2f}"
        )

    print(sep)
    print()

    # Rank agents
    ranked = sorted(summary.items(), key=lambda x: x[1]["mean"], reverse=True)
    print("Rankings (by mean score):")
    for rank, (name, stats) in enumerate(ranked, 1):
        print(f"  {rank}. {name:<12} — {stats['mean']:.4f}")

    print()

    # ------------------------------------------------------------------
    # Save JSON
    # ------------------------------------------------------------------
    os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)
    output = {
        "config": {
            "seeds": seeds,
            "n_episodes_per_seed": n_episodes_per_seed,
            "max_steps": max_steps,
            "env_module": env_module,
            "dqn_model": dqn_model_path,
        },
        "summary": summary,
        "rankings": [name for name, _ in ranked],
        "raw_results": all_results,
    }
    with open(output_path, "w") as f:
        json.dump(output, f, indent=2)
    print(f"Full results saved to: {output_path}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Benchmark LLM vs Heuristic vs DQN agents")
    p.add_argument("--seeds",       type=int, nargs="+", default=[42, 43, 44],
                   help="Seeds to evaluate on (all agents share each seed)")
    p.add_argument("--dqn-model",   default="models/dqn_cyber.pt",
                   help="Path to trained DQN weights (.pt file)")
    p.add_argument("--env-module",  default="environment",
                   help="Python import path for the environment module")
    p.add_argument("--episodes",    type=int, default=3,
                   help="Episodes per seed (heuristic/DQN only; LLM runs once per seed)")
    p.add_argument("--max-steps",   type=int, default=50)
    p.add_argument("--inference",   default="inference.py",
                   help="Path to the LLM inference script")
    p.add_argument("--no-llm",      action="store_true",
                   help="Skip the LLM agent (saves time when iterating)")
    p.add_argument("--output",      default="benchmark/results.json")
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    benchmark(
        seeds=args.seeds,
        dqn_model_path=args.dqn_model,
        env_module=args.env_module,
        n_episodes_per_seed=args.episodes,
        max_steps=args.max_steps,
        inference_script=args.inference,
        run_llm=not args.no_llm,
        output_path=args.output,
    )
